/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SnakeGame.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yourname- <marvin@42.fr>                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 4242/42/42 42:42:42 by somename-         #+#    #+#             */
/*   Updated: 4242/42/42 42:42:42 by somename-        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "canvas.h"
#include "game.h"

/* YOU CAN WRITE YOUR OWN FUNCTION DOCUMENTATION HERE*/
int	update(t_game *game)
{
	static short int	fps = 0;

	if (game->pause || fps-- != 0)
		return (1);
	fps = game->speed * 10;
	{
		remove_snake(game);
		game->snake.coords[0].x++;
		game->snake.coords[1].x++;
		game->snake.coords[2].x++;
		game->snake.coords[0].x = game->snake.coords[0].x % game_width(game);
		game->snake.coords[1].x = game->snake.coords[1].x % game_width(game);
		game->snake.coords[2].x = game->snake.coords[2].x % game_width(game);
		put_snake(game);
	}
	return (0);
}

/* YOU CAN WRITE YOUR OWN FUNCTION DOCUMENTATION HERE*/
int	read_keys(int key_pressed, void *param)
{
	t_game	*game;

	game = (t_game *)param;
	if (key_pressed == ESC || !game->img.img_ptr)
		exit_game(&game->img);
	else if (key_pressed == PAUSE)
		game->pause = !game->pause;
	else
		return (-1);
	return (0);
}
